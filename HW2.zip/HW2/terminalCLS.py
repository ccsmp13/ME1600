import os
def cls():
    os.system('cls' if os.name=='nt' else 'clear')
# Uses the function "cls" for clearing the console
cls()